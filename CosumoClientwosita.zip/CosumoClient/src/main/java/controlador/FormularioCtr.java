/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador;

import javax.swing.JOptionPane;
import modelo.usuario;
import vista.FormularioAcceso;
import vista.RegistroUsuario;
import sw.Service;
import sw.Service_Service;
import vista.CuentaUsuario;

/**
 *
 * @author 59399
 */
public class FormularioCtr {

    FormularioAcceso vista;
//    usuario us;
    RegistroUsuario vista2 = new RegistroUsuario();
    Service_Service servicio = new Service_Service();
    Service cliente = servicio.getServicePort();
    CuentaUsuario vista3 = new CuentaUsuario();

    public FormularioCtr(FormularioAcceso fda) {
        this.vista = fda;
        metodos();
    }

    public void metodos() {
        vista.getBtnRegistrar().addActionListener(l -> registrar());
//        vista.getBtnSesion().addActionListener(l -> acceder());
        vista.getBtnSesion().addActionListener(l -> Inicio_Seccion());
        vista2.getBtnRegistrarse().addActionListener(l -> registrar2());
        vista3.getBtnRegistrarse().addActionListener(l -> ModificarSaldo());

    }

    public void registrar() {
        RegistroUsuario rg = new RegistroUsuario();
        vista.setVisible(false);
        vista2.setVisible(true);

    }

    public void registrar2() {
        vista2.getTxtIngresarC().getText();
        vista2.getTxtIngresarC().getText();
        vista2.getTxtSaldo().getText();

        boolean llave = cliente.regitrarUsuario(vista2.getTxtIngresarU().getText(), vista2.getTxtIngresarC().getText(), Integer.parseInt(vista2.getTxtSaldo().getText()));
        if (llave) {
            JOptionPane.showMessageDialog(null, "Usuario Registrado");
            vista2.setVisible(false);
            vista.setVisible(true);
        } else {
            JOptionPane.showMessageDialog(null, "El usuario no puede ser registrado registrado");
        }

    }

    public void Inicio_Seccion() {
        vista.setVisible(false);
        vista3.setVisible(true);
        String llave2 = cliente.iniciarSeccion(vista.getTxtUsuario().getText(), vista.getTxtPassword().getText());
        if (llave2.equals("No exite")) {
            JOptionPane.showMessageDialog(null, "El usuario no esta registrado");
        } else {
            String[] nombre = llave2.split("-");
            String user = nombre[0];
            int saldo = Integer.parseInt(nombre[1]);
            vista3.getLbSaldo().setText(String.valueOf(saldo));
            vista3.getLbUsuario().setText(String.valueOf(user));

        }
    }

    public void ModificarSaldo() {

        if (vista3.getRdbD().isSelected()) {
            int result = Integer.parseInt(vista3.getLbSaldo().getText());
            int fd = Integer.parseInt(vista3.getTxtValor().getText());
            int total = result + fd;
          
            int valor = cliente.updateSaldo(vista3.getLbUsuario().getText(), total);

            if (valor == -1) {
                JOptionPane.showMessageDialog(null, "No se pudo realizar la operacion de deposito");
            } else {
                vista3.getLbSaldo().setText(String.valueOf(valor));
            }

        } else {
            int result = Integer.parseInt(vista3.getLbSaldo().getText());
            int fd = Integer.parseInt(vista3.getTxtValor().getText());
            if (fd > result) {
                JOptionPane.showMessageDialog(null, "No sepuede sacar mas dinero.");
            } else {
                int total = result - fd;

                int valor = cliente.updateSaldo(vista3.getLbUsuario().getText(), total);
                if (valor == -1) {
                    JOptionPane.showMessageDialog(null, "No se pudo realizar la operacion retiro");
                } else {
                    vista3.getLbSaldo().setText(String.valueOf(valor));
                }
            }

        }
    }

}
