/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import sv.Service;
import sv.Service_Service;

/**
 *
 * @author 59399
 */
public class modelo_usuario {

    Service_Service servicio = new Service_Service();
    Service cliente = servicio.getServicePort();

    public void Registra() {

//        usuario us = new usuario();
//        us.setPassword(password);
//        System.out.println(cliente.formulaSuma(15));
//        System.out.println(cliente.ecuacion(2, 2));
    }

}
