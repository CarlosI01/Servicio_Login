/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

//
import controlador.FormularioCtr;
import sw.Service_Service;
import sw.Service;
import vista.FormularioAcceso;

public class ClienteConsume {

    public static void main(String[] args) {
////        
        FormularioAcceso vista= new FormularioAcceso();
        usuario modelo= new usuario();
       FormularioCtr crt= new FormularioCtr(vista);
        vista.setVisible(true);
//        
//        Service_Service servicio = new Service_Service();
//        Service cliente = servicio.getServicePort();
//        System.out.println(cliente.login("CarlosTH", "12345"));

//        System.out.println(cliente.potencia(12, 2));
//        System.out.println(cliente.diccionario("1"));
//        System.out.println(cliente.hello("carlos"));
        
        //Usuario, Password
        //System.out.println(cliente.login("TheWosita", "12345"));
        
        //Primer valor, Segundo valor, Opcion
//        System.out.println(cliente.operacioneBasicas(1, 2, 1));

//        System.out.println(cliente.formulaSuma(15));
//        System.out.println(cliente.ecuacion(2, 2));
//        System.out.println(cliente.movimientoUniforme(2, 2));
        


    }
}
