/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sw;

import java.util.ArrayList;
import java.util.List;
import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

/**
 *
 * @author 59399
 */
@WebService(serviceName = "Service")
public class Service {

    /**
     * This is a sample web service operation
     */
    @WebMethod(operationName = "hello")
    public String hello(@WebParam(name = "name") String txt) {
        return "Hello " + txt + " !";
    }

    ArrayList<usuario> list = new ArrayList<>();

    @WebMethod(operationName = "RegitrarUsuario")
    public Boolean RegitrarUsuario(@WebParam(name = "Usuario") String usuario, @WebParam(name = "Password") String password, @WebParam(name = "repeat") int repeat) {
        boolean llave = false;
        for (int i = 0; i < list.size(); i++) {

            if (list.get(i).getUsuario().equals(usuario)) {
                llave = true;
                break;
            }

        }
        if (llave) {
            return false;
        } else {
            usuario us= new usuario();
            us.setUsuario(usuario);
            us.setPassword(password);
            us.setValor(repeat);
            list.add(us);
            
            return true;
        }
    }

    @WebMethod(operationName = "Iniciar_seccion")
    public String IniciarSeccio(@WebParam(name = "Usuario") String usuario, @WebParam(name = "Password") String password) {
        boolean llave = false;
        String usuario_c="";
        int saldo=0;
        for (int i = 0; i < list.size(); i++) {

            if (list.get(i).getUsuario().equals(usuario) && list.get(i).getPassword().equals(password)) {
                usuario_c=list.get(i).getUsuario();
                saldo= list.get(i).getValor();
                llave = true;
                break;
            }

        }
        if (llave) {
            return usuario_c+ "-" +saldo;
        } else {
                    
            return "No exite";
        }
    }
  @WebMethod(operationName = "UpdateSaldo")
    public Integer UpdateSaldo(@WebParam(name = "Usuario") String usuario, @WebParam(name = "saldo") int saldo) {
        boolean llave = false;
        
        for (int i = 0; i < list.size(); i++) {

            if (list.get(i).getUsuario().equals(usuario)) {
                list.get(i).setValor(saldo);
                llave = true;
                break;
            }

        }
        if (llave) {
            return saldo;
        } else {    
            return -1;
        }
    }

    public class usuario {

        private String usuario;
        private String password;
        private int valor;

        public String getUsuario() {
            return usuario;
        }

        public void setUsuario(String usuario) {
            this.usuario = usuario;
        }

        public String getPassword() {
            return password;
        }

        public void setPassword(String password) {
            this.password = password;
        }

        public int getValor() {
            return valor;
        }

        public void setValor(int valor) {
            this.valor = valor;
        }

    }

}
